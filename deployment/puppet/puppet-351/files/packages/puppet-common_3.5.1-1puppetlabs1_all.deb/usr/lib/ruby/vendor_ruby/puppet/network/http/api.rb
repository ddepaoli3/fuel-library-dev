class Puppet::Network::HTTP::API
end
