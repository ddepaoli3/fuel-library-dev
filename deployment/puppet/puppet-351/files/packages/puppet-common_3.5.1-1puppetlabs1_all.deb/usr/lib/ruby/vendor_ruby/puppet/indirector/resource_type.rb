require 'puppet/resource/type'

# A stub class, so our constants work.
class Puppet::Indirector::ResourceType # :nodoc:
end
