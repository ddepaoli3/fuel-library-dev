# A stub class, so our constants work.
class Puppet::Indirector::InstrumentationData
end
