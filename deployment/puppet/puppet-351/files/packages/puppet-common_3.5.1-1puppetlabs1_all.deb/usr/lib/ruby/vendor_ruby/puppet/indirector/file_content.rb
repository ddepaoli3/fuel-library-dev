# A stub class, so our constants work.
class Puppet::Indirector::FileContent # :nodoc:
end

require 'puppet/file_serving/content'
