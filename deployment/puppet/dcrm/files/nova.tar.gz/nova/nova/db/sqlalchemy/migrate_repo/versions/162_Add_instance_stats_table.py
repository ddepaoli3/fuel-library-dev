from sqlalchemy import MetaData, Table, Index, Column
from sqlalchemy import String, Integer, Boolean, DateTime
from nova.openstack.common import log as logging
LOG = logging.getLogger(__name__)
meta = MetaData()
instance_stats_table = Table('instance_stats', meta, Column('created_at', DateTime), Column('updated_at', DateTime), Column('deleted_at', DateTime), Column('deleted', Integer), Column('id', Integer, primary_key=True, nullable=False), Column('instance_uuid', String(length=36), nullable=False), Column('key', String(length=255), nullable=False), Column('value', String(length=255)), mysql_engine='InnoDB', mysql_charset='utf8')

def upgrade(migrate_engine):
    meta.bind = migrate_engine
    try:
        instance_stats_table.create()
    except Exception:
        LOG.info(repr(instance_stats_table))
        LOG.exception(_('Exception while creating table.'))
        raise 
    instance_stats_index = Index('ix_instance_stats_instance_uuid', instance_stats_table.c.instance_uuid)
    try:
        instance_stats_index.create(migrate_engine)
    except Exception:
        LOG.info(repr(instance_stats_index))
        LOG.exception(_('Exception while creating index.'))
        raise 



def downgrade(migrate_engine):
    meta.bind = migrate_engine
    instance_stats_index = Index('ix_instance_stats_instance_uuid', instance_stats_table.c.instance_uuid)
    try:
        instance_stats_index.drop()
    except Exception:
        LOG.info(repr(instance_stats_index))
        LOG.exception(_('Exception while dropping index.'))
        raise 
    try:
        instance_stats_table.drop()
    except Exception:
        LOG.info(repr(instance_stats_table))
        LOG.exception(_('Exception while dropping table.'))
        raise 

